compile q1a:
g++ q1a.cpp

compile q1b:
g++ q1b.cpp -mavx