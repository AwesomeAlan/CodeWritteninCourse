compile:
g++ q3.cpp -fopenmp