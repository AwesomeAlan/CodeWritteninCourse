compile:
g++ q4.cpp -fopenmp