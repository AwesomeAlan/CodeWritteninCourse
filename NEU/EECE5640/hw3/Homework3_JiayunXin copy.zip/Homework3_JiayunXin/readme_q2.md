compile:
g++ -pthread q2.cpp