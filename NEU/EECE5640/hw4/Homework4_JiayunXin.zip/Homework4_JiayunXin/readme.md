Homework4
Jiayun Xin

Q1
preprocess: module load openmpi
Compile: mpic++ q1.cpp
Execute(node number can be changed): mpirun -n 4 ./a.out

Q2a
Compile: mpic++ q2a.cpp
Execute(node number can be changed): mpirun -n 4 ./a.out

Q2b
Compile: mpic++ q2b.cpp
Execute(node number can be changed): mpirun -n 4 ./a.out