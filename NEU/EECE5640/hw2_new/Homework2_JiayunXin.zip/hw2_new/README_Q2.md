#complie for Q2a and Q2b:
g++-11 -fopenmp Q2a.cpp
g++-11 -fopenmp Q2b.cpp